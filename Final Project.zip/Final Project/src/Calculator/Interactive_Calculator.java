package Calculator;

import java.util.Scanner;

public class Interactive_Calculator {

	public static void main(String[] args) {
		double num1, num2, output;
		char operator, choice;
		
		Scanner input = new Scanner(System.in);
		
		do {

			System.out.println("Hello, welcome to the calculator");
			
			System.out.println("Enter 1st number: ");
			num1 = input.nextDouble();
		
			System.out.println("Enter 2nd number: ");
			num2 = input.nextDouble();
	
			System.out.print("Enter operator (+, -, *, /): ");
			operator = input.next().charAt(0);
				
			switch(operator)
			{
				case '+':
					output = num1 + num2;
					break;

				case '-':
					output = num1 - num2;
					break;

				case '*':
					output = num1 * num2;
					break;

				case '/':
					output = num1 / num2;
					break;

				default:
					System.out.printf("You have entered wrong operator");
					return;
			}

		System.out.println(num1+" "+operator+" "+num2+" = "+output);
		
    	System.out.println("Do you want to continue (Y/N): ");        
    	choice = input.next().charAt(0);

		}while(choice =='y'||choice == 'Y');
		input.close();
		}
}
