
public class IntegerPlus1 {

	 public static void main(int []args) {
		int a = 1;
		int b = a+1;
		 
		
		 System.out.println(b);
	 }
}
