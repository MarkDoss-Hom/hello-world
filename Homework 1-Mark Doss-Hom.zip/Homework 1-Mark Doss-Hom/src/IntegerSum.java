
public class IntegerSum {

	 public static void main(int []args) {
		int a = 1;
		int b = 2;
		 
		int c = a+b;
		
		 System.out.println(c);
	 }
}
